import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'database_helper.dart';
import 'car_list_page.dart';

class SellCarPage extends StatefulWidget {
  @override
  _SellCarPageState createState() => _SellCarPageState();
}

class _SellCarPageState extends State<SellCarPage> {
  final _formKey = GlobalKey<FormState>();

  late String _brand;
  late String _model;
  late int _manufacturingYear;
  late String _fuelType;
  late String _variant;
  late int _kmDriven;
  late String _carLocation;
  late DateTime _plannedSellingDate;
  late String _mobileNumber;
  late String _rtoCode; // New field for RTO code
  late double _price; // New field for price
  XFile? _imageFile;

  @override
  void initState() {
    super.initState();
    _brand = '';
    _model = '';
    _manufacturingYear = 0;
    _fuelType = '';
    _variant = '';
    _kmDriven = 0;
    _carLocation = '';
    _plannedSellingDate = DateTime.now();
    _mobileNumber = '';
    _rtoCode = '';
    _price = 0.0;
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    setState(() {
      _imageFile = pickedFile;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sell a Car'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextFormField(
                  decoration: InputDecoration(labelText: 'Brand', border: OutlineInputBorder()),
                  validator: (value) {
                    if (value?.isEmpty ?? true) {
                      return 'Please enter the brand';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    _brand = value;
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Model', border: OutlineInputBorder()),
                  validator: (value) {
                    if (value?.isEmpty ?? true) {
                      return 'Please enter the model';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    _model = value;
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Manufacturing Year', border: OutlineInputBorder()),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value?.isEmpty ?? true) {
                      return 'Please enter the manufacturing year';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    _manufacturingYear = int.tryParse(value ?? '0') ?? 0;
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Fuel Type', border: OutlineInputBorder()),
                  validator: (value) {
                    if (value?.isEmpty ?? true) {
                      return 'Please enter the fuel type';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    _fuelType = value;
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Variant', border: OutlineInputBorder()),
                  validator: (value) {
                    if (value?.isEmpty ?? true) {
                      return 'Please enter the variant';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    _variant = value;
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Kilometers Driven', border: OutlineInputBorder()),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value?.isEmpty ?? true) {
                      return 'Please enter the kilometers driven';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    _kmDriven = int.tryParse(value ?? '0') ?? 0;
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Car Location', border: OutlineInputBorder()),
                  validator: (value) {
                    if (value?.isEmpty ?? true) {
                      return 'Please enter the car location';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    _carLocation = value;
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Planned Selling Date', border: OutlineInputBorder()),
                  validator: (value) {
                    // Add validation logic if needed
                    return null;
                  },
                  onChanged: (value) {
                    // Handle planned selling date
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Mobile Number', border: OutlineInputBorder()),
                  keyboardType: TextInputType.phone,
                  validator: (value) {
                    if (value?.isEmpty ?? true) {
                      return 'Please enter the mobile number';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    _mobileNumber = value;
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  decoration: InputDecoration(labelText: 'RTO Code', border: OutlineInputBorder()), // New field for RTO code
                  validator: (value) {
                    if (value?.isEmpty ?? true) {
                      return 'Please enter the RTO code';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    _rtoCode = value;
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Price', border: OutlineInputBorder()), // New field for price
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value?.isEmpty ?? true) {
                      return 'Please enter the price';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    _price = double.tryParse(value ?? '0.0') ?? 0.0;
                  },
                ),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: _pickImage,
                  child: Text('Pick Image'),
                ),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState?.validate() ?? false) {
                      _submitForm(context);
                    }
                  },
                  child: Text('Submit'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _submitForm(BuildContext context) async {
    final carData = {
    'brand': _brand,
    'model': _model,
    'manufacturingYear': _manufacturingYear,
    'fuelType': _fuelType,
    'variant': _variant,
    'kmDriven': _kmDriven,
    'carLocation': _carLocation,
    'plannedSellingDate': _plannedSellingDate.toIso8601String(),
    'mobileNumber': _mobileNumber,
    'rtoCode': _rtoCode, // Add RTO code to car data
    'price': _price, // Add price to car data
      'imagePath': _imageFile?.path,
    };

    await DatabaseHelper().insertCar(carData);

    _formKey.currentState?.reset();

    // Navigate to car list page and pass the image path
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CarListPage(),
      ),
    );
  }
}

