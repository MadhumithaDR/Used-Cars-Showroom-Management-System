import 'package:flutter/material.dart';

class ListedCarsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Listed Cars'),
      ),
      body: Center(
        child: Text('Listed Cars will be displayed here'),
      ),
    );
  }
}
