import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static late Database _database;

  Future<Database> get database async {
    _database = await _initDatabase();
    return _database;
  }

  Future<Database> _initDatabase() async {
    return openDatabase(
      join(await getDatabasesPath(), 'cars_database.db'),
      onCreate: (db, version) {
        return db.execute(
          'CREATE TABLE cars(id INTEGER PRIMARY KEY, brand TEXT, model TEXT, manufacturingYear INTEGER, fuelType TEXT, variant TEXT, kmDriven INTEGER, carLocation TEXT, plannedSellingDate TEXT, mobileNumber TEXT, rtoCode TEXT, price REAL, imagePath TEXT)', // Include imagePath, RTO code, and price columns here
        );
      },
      version: 4,
    );
  }

  Future<void> insertCar(Map<String, dynamic> carData) async {
    final Database db = await database;
    await db.insert(
      'cars',
      carData,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateCar(int id, Map<String, dynamic> updatedCarData) async {
    final Database db = await database;
    await db.update(
      'cars',
      updatedCarData,
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<List<Map<String, dynamic>>> getAllCars() async {
    final Database db = await database;
    return await db.query('cars');
  }
}

void main() async {
  // Update the RTO code and price of the car with ID 1
  await updateCarDetails();
}

Future<void> updateCarDetails() async {
  // Specify the ID of the car to update
  int carIdToUpdate = 1;

  // Define the updated values for RTO code and price
  Map<String, dynamic> updatedCarData = {
    'rtoCode': 'TN 78', // Updated RTO code
    'price': 869000, // Updated price
    // Add more fields and their updated values as needed
  };

  // Call the updateCar method to update the car details
  await DatabaseHelper().updateCar(carIdToUpdate, updatedCarData);

  print('Car details updated successfully.');
}
