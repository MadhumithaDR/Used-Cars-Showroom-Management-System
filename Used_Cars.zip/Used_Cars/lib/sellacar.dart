import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sell Your Car App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: SellACar(), // Use SellACar widget as home
    );
  }
}

class SellACar extends StatelessWidget {
  final TextEditingController brandController = TextEditingController();
  final TextEditingController manufacturingYearController =
  TextEditingController();
  final TextEditingController modelController = TextEditingController();
  final TextEditingController fuelTypeController = TextEditingController();
  final TextEditingController variantController = TextEditingController();
  final TextEditingController stateController = TextEditingController();
  final TextEditingController rtocodeController = TextEditingController();
  final TextEditingController kmdrivenController = TextEditingController();
  final TextEditingController car_locationController = TextEditingController();
  final TextEditingController planned_selling_dateController = TextEditingController();
  final TextEditingController mobile_numberController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sell Your Car'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: ListView(
          shrinkWrap: true,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Enter Car Details',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: brandController,
                  decoration: InputDecoration(
                    labelText: 'Brand',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: manufacturingYearController,
                  decoration: InputDecoration(
                    labelText: 'Manufacturing Year',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.number,
                ),
                SizedBox(height: 20),
                TextField(
                  controller: modelController,
                  decoration: InputDecoration(
                    labelText: 'Model',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: fuelTypeController,
                  decoration: InputDecoration(
                    labelText: 'Fuel Type',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: variantController,
                  decoration: InputDecoration(
                    labelText: 'Variant',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: stateController,
                  decoration: InputDecoration(
                    labelText: 'State',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: rtocodeController,
                  decoration: InputDecoration(
                    labelText: 'RTO Code',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: kmdrivenController,
                  decoration: InputDecoration(
                    labelText: 'KM Driven',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: car_locationController,
                  decoration: InputDecoration(
                    labelText: 'Car Location',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: planned_selling_dateController,
                  decoration: InputDecoration(
                    labelText: 'Planned Selling Date',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: mobile_numberController,
                  decoration: InputDecoration(
                    labelText: 'Mobile Number',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    _listCar(context);
                  },
                  child: Text('List Your Car'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _listCar(BuildContext context) async {
    var url = Uri.parse('http://192.168.56.1/insert_car.php'); // Replace with your PHP script URL
    var response = await http.post(url, body: {
      'brand': brandController.text,
      'manufacturingYear': manufacturingYearController.text,
      'model':modelController.text,
      'fuelType':fuelTypeController.text,
      'variant' :variantController.text,
      'state' :stateController.text,
      'rtocode' :rtocodeController.text,
      'kmdriven' :kmdrivenController.text,
      'car_location' :car_locationController.text,
      'planned_selling_date' :planned_selling_dateController.text,
      'mobile_number' :mobile_numberController.text,
    });

    if (response.statusCode == 200) {
      // Handle successful response
      print('Car listed successfully');
    } else {
      // Handle error
      print("Failed to list car: ${response.reasonPhrase}");
    }
  }
}