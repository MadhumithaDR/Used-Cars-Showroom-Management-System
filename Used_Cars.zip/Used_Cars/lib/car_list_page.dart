// car_list_page.dart

import 'dart:io';
import 'package:flutter/material.dart';
import 'database_helper.dart';
import 'car_details_page.dart';

class CarListPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('List of Cars'),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: DatabaseHelper().getAllCars(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          } else {
            final cars = snapshot.data ?? [];
            return ListView.builder(
              itemCount: cars.length,
              itemBuilder: (context, index) {
                final car = cars[index];
                return CarListItem(car: car);
              },
            );
          }
        },
      ),
    );
  }
}

class CarListItem extends StatelessWidget {
  final Map<String, dynamic> car;

  const CarListItem({Key? key, required this.car}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final String brand = car['brand'] ?? 'Unknown';
    final String model = car['model'] ?? '';
    final String variant = car['variant'] ?? '';
    final String imagePath = car['imagePath'] ?? '';

    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => CarDetailsPage(car: car),
          ),
        );
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Display the image of the car
          Container(
            height: 200,
            width: double.infinity,
            child: imagePath.isNotEmpty
                ? Image.file(
              File(imagePath),
              fit: BoxFit.cover,
            )
                : Placeholder(), // Placeholder if no image available
          ),
          // Display the brand, model, and variant
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Brand: $brand',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Text('Model: $model'),
                Text('Variant: $variant'),
                // Add more fields as needed
                SizedBox(height: 8),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CarDetailsPage(car: car),
                      ),
                    );
                  },
                  child: Text('Click here for more information!'),
                ),
              ],
            ),
          ),
          Divider(),
        ],
      ),
    );
  }
}
