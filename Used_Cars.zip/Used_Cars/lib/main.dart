import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:used_cars/home.dart';
import 'package:used_cars/sellcarpage.dart';
import 'package:used_cars/car_list_page.dart';
import 'package:used_cars/aboutUs.dart';
// Import the SellCarPage class

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => AuthProvider(),
      child: MyApp(),
    ),
  );
}

class AuthProvider with ChangeNotifier {
  bool _isSignedIn = false;

  bool get isSignedIn => _isSignedIn;

  void signIn() {
    _isSignedIn = true;
    notifyListeners();
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomePage(),
      routes: {
        '/main': (context) => MyApp(),
        '/login': (context) => LoginPage(),
        '/sell_car': (context) => SellCarPage(),
        '/car_list_page': (context) => CarListPage(),
        '/about_us': (context) => AboutUsPage(), // Update route for SellCarPage
      },
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      appBar: AppBar(
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: GestureDetector(
              onTap: () {
                // Handle sign-in navigation
                if (!authProvider.isSignedIn) {
                  // Navigate to LoginPage
                  Navigator.pushNamed(context, '/login');
                }
              },
              child: Row(
                children: [
                  Icon(
                    Icons.person,
                    size: 30.0,
                  ),
                  SizedBox(width: 5),
                  Text(
                    'Sign In',
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: EdgeInsets.symmetric(vertical: 16),
            color: Colors.black,
            child: Text(
              'USED CARS SHOWROOM',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/bg4.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
        ],
      ),
      drawer: DrawerWidget(),
    );
  }
}

class DrawerWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.blueGrey,
            ),
            child: Text(
              'Menu',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
              ),
            ),
          ),
          ListTile(
            title: Text('Home'),
            onTap: () {
              // Handle home navigation
              Navigator.pop(context);
            },
          ),
          ListTile(
            title: Text('About us'),
            onTap: () {
              // Handle about us navigation
              Navigator.pop(context);
              Navigator.pushNamed(context, '/about_us');
            },
          ),
          ListTile(
            title: Text('Buy a car'),
            onTap: () {
              // Handle buy a car navigation
              Navigator.pop(context);
              Navigator.pushNamed(context, '/car_list_page');
            },
          ),
          ListTile(
            title: Text('Sell a car'),
            onTap: () {
              // Navigate to SellCarPage
              Navigator.pop(context); // Close the drawer first
              Navigator.pushNamed(context, '/sell_car');
            },
          ),
        ],
      ),
    );
  }
}
