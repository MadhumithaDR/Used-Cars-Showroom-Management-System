<?php
$servername = "localhost";
$username = "root";
$password = "amaraa";
$database = "used_cars";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

header('Content-Type: application/json');

$brand = isset($_GET['brand']) ? $_GET['brand'] : '';
$year = isset($_GET['year']) ? $_GET['year'] : '';
$budget = isset($_GET['budget']) ? $_GET['budget'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';

$sql = "SELECT * FROM cars WHERE 1";

if (!empty($brand)) {
    $sql .= " AND brand = '$brand'";
}

if (!empty($year)) {
    $sql .= " AND year = $year";
}

if (!empty($budget)) {
    $sql .= " AND price <= $budget";
}

if (!empty($search)) {
    $sql .= " AND (brand LIKE '%$search%' OR model LIKE '%$search%')";
}

$result = $conn->query($sql);

if ($result === false) {
    die('Error executing query: ' . $conn->error);
}

if ($result->num_rows > 0) {
    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode(array('success' => true, 'data' => $data));
} else {
    echo json_encode(array('success' => false, 'message' => 'No cars found matching the criteria.'));
}

$conn->close();
?>
